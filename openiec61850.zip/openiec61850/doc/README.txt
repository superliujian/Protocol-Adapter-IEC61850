
Authors:
Stefan Feuerhahn
Claus Brunzema
Bertram Lückehe
Chau Do
Tobias Weidelt
Michael Zillgith

For documentation take a look at the user guide in the doc/userguide
folder of the distribution or online at http://www.openmuc.org.

The user guide includes information about the licenses of the
individual libraries/applications that are part of the OpenIEC61850
distribution.
