rm ../../src/main/java/org/openmuc/josistack/internal/acse/asn1/*
jasn1-compiler.sh -o "../../src/main/java/org/openmuc/josistack/internal/acse/asn1/" -f isoAcseLayer.asn -ns "org.openmuc.josistack.internal.acse.asn1"
