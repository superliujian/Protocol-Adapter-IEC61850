rm ../../src/main/java/org/openmuc/josistack/internal/presentation/asn1/*.java
jasn1-compiler.sh -o "../../src/main/java/org/openmuc/josistack/internal/presentation/asn1" -f isoPresentationLayer.asn -ns "org.openmuc.josistack.internal.presentation.asn1"
