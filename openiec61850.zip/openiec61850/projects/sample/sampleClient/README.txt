
In order to run the sample client on Windows you have to rename runSampleClient.bat.winfile to runSampleClient.bat.
