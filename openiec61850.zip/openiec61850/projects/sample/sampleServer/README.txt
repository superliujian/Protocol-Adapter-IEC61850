
In order to run the sample server on Windows you have to rename runSampleServer.bat.winfile to runSampleServer.bat.
