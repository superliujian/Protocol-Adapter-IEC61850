rm ../../src/main/java/org/openmuc/openiec61850/internal/mms/asn1/*
jasn1-compiler.sh -o "../../src/main/java/org/openmuc/openiec61850/internal/mms/asn1/" -f mms.asn -ns "org.openmuc.openiec61850.internal.mms.asn1"
