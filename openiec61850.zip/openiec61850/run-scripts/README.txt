
In order to run the Client GUI on Windows you have to rename openiec61850-clientgui.bat.winfile to openiec61850-clientgui.bat .
